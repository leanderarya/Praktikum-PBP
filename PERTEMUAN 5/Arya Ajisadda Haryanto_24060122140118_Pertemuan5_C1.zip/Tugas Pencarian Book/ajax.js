// Nama   : Arya Ajisadda Haryanto
// NIM    : 24060122140118
// Lab    : PBP C1

// Fungsi untuk mencari buku berdasarkan judul
function searchBooks(title) {
  if (title.length == 0) {
    document.getElementById("book_list").innerHTML = "";
    return;
  }

  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("book_list").innerHTML = this.responseText;
    }
  };

  xmlhttp.open("GET", "get_books.php?title=" + title, true);
  xmlhttp.send();
}

// Fungsi untuk menampilkan detail buku berdasarkan ISBN
function showBookDetails(isbn) {
  if (isbn == "") {
    document.getElementById("book_details").innerHTML = "";
    return;
  }

  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("book_details").innerHTML = this.responseText;
    }
  };

  xmlhttp.open("GET", "get_books.php?isbn=" + isbn, true);
  xmlhttp.send();
}
