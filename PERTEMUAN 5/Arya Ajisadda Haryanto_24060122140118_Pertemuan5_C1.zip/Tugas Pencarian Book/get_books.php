<!-- 
    Nama   : Arya Ajisadda Haryanto
    NIM    : 24060122140118
    Lab    : PBP C1
-->
<?php
require_once('lib/db_login.php');

if (isset($_GET['title'])) {
    $title = $db->real_escape_string($_GET['title']);

    $query = "SELECT isbn, title FROM books WHERE title LIKE '%$title%' LIMIT 10";
    $result = $db->query($query);

    if ($result->num_rows > 0) {
        echo "<ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li><a href='#' onclick='showBookDetails(\"" . $row['isbn'] . "\")'>" . $row['title'] . "</a></li>";
        }
        echo "</ul>";
    } else {
        echo "Tidak ada buku yang ditemukan";
    }
}

if (isset($_GET['isbn'])) {
    $isbn = $db->real_escape_string($_GET['isbn']);
    
    $query = "
        SELECT books.isbn, books.title, books.author, books.price, categories.name AS category 
        FROM books 
        JOIN categories ON books.categoryid = categories.categoryid 
        WHERE books.isbn = '$isbn'
    ";
    $result = $db->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<h2>Detail Buku</h2>";
        echo "Judul: " . $row['title'] . "<br>";
        echo "Penulis: " . $row['author'] . "<br>";
        echo "Kategori: " . $row['category'] . "<br>";
        echo "Harga: $" . number_format($row['price'], 2) . "<br>";
    } else {
        echo "Detail buku tidak ditemukan";
    }

    $review_query = "SELECT review FROM book_reviews WHERE isbn = '$isbn'";
    $review_result = $db->query($review_query);

    if ($review_result->num_rows > 0) {
        $review_row = $review_result->fetch_assoc();
        echo "<h3>Ulasan Buku</h3>";
        echo nl2br($review_row['review']);
    }

    $result->free();
    $review_result->free();
}

$db->close();
?>