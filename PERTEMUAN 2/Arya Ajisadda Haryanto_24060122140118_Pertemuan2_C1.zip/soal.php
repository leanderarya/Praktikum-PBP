<?php

// Nama       : Arya Ajisadda Haryanto
// NIM        : 24060122140118
// Deskripsi  : Praktikum PBP C1, Menghitung rata-rata nilai

function hitung_rata($array) {
    return array_sum($array) / count($array);
}

function print_mhs($array_mhs) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>Nama</th>";
    echo "<th>Nilai 1</th>";
    echo "<th>Nilai 2</th>";
    echo "<th>Nilai 3</th>";
    echo "<th>Rata-rata</th>";
    echo "</tr>";
    
    foreach ($array_mhs as $nama => $nilai) {
        echo "<tr>";
        echo "<td>$nama</td>";
        echo "<td>{$nilai[0]}</td>";
        echo "<td>{$nilai[1]}</td>";
        echo "<td>{$nilai[2]}</td>";

        $rata2 = hitung_rata($nilai);
        echo "<td>" . $rata2 . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

$array_mhs = array(
    'Abdul' => array(89, 90, 54),
    'Budi' => array(78, 60, 64),
    'Nina' => array(67, 56, 84),
    'Budi' => array(87, 69, 50),
    'Budi' => array(98, 65, 74)
);
print_mhs($array_mhs);
?>

